INSERT INTO company (
    company_name,
    business_type,
    main_cargo_type
)
VALUES (
    '세이프물류',
    '화물운송',
    '일반화물'
);

INSERT INTO logistics_center (
    company_id,
    center_name,
    address,
    latitude,
    longitude,
    open_time,
    close_time
)
VALUES
(
    1,
    '서울물류센터',
    '서울특별시',
    37.5665,
    126.9780,
    '06:00',
    '23:00'
),
(
    1,
    '평택물류센터',
    '경기도 평택시',
    36.9921,
    127.1129,
    '06:00',
    '23:00'
);

INSERT INTO driver (
    company_id,
    driver_name,
    age,
    driving_experience,
    license_type
)
VALUES
(
    1,
    '김안전',
    42,
    15,
    '1종 대형'
),
(
    1,
    '이운전',
    35,
    8,
    '1종 대형'
);

INSERT INTO vehicle (
    company_id,
    license_plate,
    vehicle_type,
    vehicle_model,
    model_year,
    max_load_weight_kg
)
VALUES
(
    1,
    '12가3456',
    '화물차',
    '5톤 트럭',
    2023,
    5000
),
(
    1,
    '34나5678',
    '화물차',
    '1톤 트럭',
    2024,
    1000
);

SELECT * FROM company;
SELECT * FROM logistics_center;
SELECT * FROM driver;
SELECT * FROM vehicle;