from __future__ import annotations

import os
from typing import Any

import requests


WAREHOUSE_API_URL = (
    "http://apis.data.go.kr/1611000/whsinfoview2/WhsInfoList"
)

DEFAULT_TIMEOUT = (3.05, 10)


class WarehouseApiError(RuntimeError):
    """국토교통부 물류창고업등록정보 API 호출 실패."""


def _get_service_key() -> str:
    key = os.getenv("MOLIT_WAREHOUSE_API_KEY", "").strip()

    if not key:
        raise WarehouseApiError(
            "MOLIT_WAREHOUSE_API_KEY 환경변수가 설정되지 않았습니다."
        )

    return key


def _extract_items(data: Any) -> list[dict[str, Any]]:
    """공공데이터포털 JSON 응답에서 실제 목록을 안전하게 꺼냅니다."""
    if not isinstance(data, dict):
        return []

    response = data.get("response", data)

    if isinstance(response, dict):
        body = response.get("body", response)
    else:
        body = {}

    if not isinstance(body, dict):
        return []

    items = body.get("items", [])

    if isinstance(items, dict):
        items = items.get("item", [])

    if isinstance(items, dict):
        return [items]

    if isinstance(items, list):
        return [item for item in items if isinstance(item, dict)]

    direct_items = data.get("items")

    if isinstance(direct_items, dict):
        direct_items = direct_items.get("item", [])

    if isinstance(direct_items, dict):
        return [direct_items]

    if isinstance(direct_items, list):
        return [
            item for item in direct_items
            if isinstance(item, dict)
        ]

    return []


def _pick(
    item: dict[str, Any],
    *names: str,
    default: Any = "",
) -> Any:
    """응답 필드의 대소문자 차이를 허용해 값을 찾습니다."""
    if not item:
        return default

    lowered = {
        str(key).lower(): value
        for key, value in item.items()
    }

    for name in names:
        if name in item:
            return item[name]

        value = lowered.get(name.lower())
        if value is not None:
            return value

    return default


def _normalize_item(item: dict[str, Any]) -> dict[str, Any]:
    """
    프로젝트에서 쓰기 쉬운 이름으로 변환합니다.

    공식 목록 API에서 확인되는 핵심 값:
    - COMPANY_NAME: 업체명
    - STORAGE_ITEM: 보관품목
    - WARE_NO: 창고번호
    - RNUM: 레코드 번호
    """
    return {
        "company_name": str(
            _pick(
                item,
                "COMPANY_NAME",
                "companyName",
                "company_name",
            )
            or ""
        ).strip(),
        "storage_item": str(
            _pick(
                item,
                "STORAGE_ITEM",
                "storageItem",
                "storage_item",
            )
            or ""
        ).strip(),
        "warehouse_no": str(
            _pick(
                item,
                "WARE_NO",
                "wareNo",
                "warehouse_no",
            )
            or ""
        ).strip(),
        "record_no": str(
            _pick(
                item,
                "RNUM",
                "rnum",
                "record_no",
            )
            or ""
        ).strip(),
        "raw": item,
    }


def request_warehouse_list(
    page_no: int = 1,
    num_of_rows: int = 100,
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict[str, Any]:
    """
    국토교통부 물류창고업등록정보 목록 API를 한 페이지 조회합니다.

    start_date / end_date:
        YYYYMMDD 형식. 필요할 때만 전달합니다.
    """
    page_no = max(1, int(page_no))
    num_of_rows = max(1, min(500, int(num_of_rows)))

    params: dict[str, Any] = {
        "ServiceKey": _get_service_key(),
        "pageNo": page_no,
        "numOfRows": num_of_rows,
        "type": "json",
    }

    if start_date:
        params["sday"] = str(start_date).strip()

    if end_date:
        params["eday"] = str(end_date).strip()

    try:
        response = requests.get(
            WAREHOUSE_API_URL,
            params=params,
            timeout=DEFAULT_TIMEOUT,
        )
    except requests.RequestException as exc:
        raise WarehouseApiError(
            f"물류창고 API 서버에 연결하지 못했습니다: {exc}"
        ) from exc

    if not response.ok:
        raise WarehouseApiError(
            "물류창고 API 조회 실패 "
            f"(HTTP {response.status_code}): "
            f"{response.text[:300]}"
        )

    try:
        data = response.json()
    except ValueError as exc:
        raise WarehouseApiError(
            "물류창고 API 응답을 JSON으로 해석하지 못했습니다."
        ) from exc

    items = [
        _normalize_item(item)
        for item in _extract_items(data)
    ]

    return {
        "page_no": page_no,
        "num_of_rows": num_of_rows,
        "count": len(items),
        "items": items,
        "raw": data,
    }


def search_warehouses(
    company_name: str | None = None,
    storage_item: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    max_pages: int = 10,
    page_size: int = 500,
) -> list[dict[str, Any]]:
    """
    여러 페이지를 조회한 뒤 업체명/보관품목으로 필터링합니다.

    공개된 목록 API 기준으로 업체명 검색 파라미터가 확인되지 않아,
    필요한 범위를 페이지로 가져온 뒤 로컬에서 필터링합니다.
    """
    company_query = str(company_name or "").strip().lower()
    storage_query = str(storage_item or "").strip().lower()

    results: list[dict[str, Any]] = []

    for page_no in range(1, max(1, int(max_pages)) + 1):
        result = request_warehouse_list(
            page_no=page_no,
            num_of_rows=page_size,
            start_date=start_date,
            end_date=end_date,
        )

        items = result["items"]

        if not items:
            break

        for item in items:
            company_ok = (
                not company_query
                or company_query in item["company_name"].lower()
            )
            storage_ok = (
                not storage_query
                or storage_query in item["storage_item"].lower()
            )

            if company_ok and storage_ok:
                results.append(item)

        if len(items) < min(500, page_size):
            break

    return results


if __name__ == "__main__":
    result = request_warehouse_list(
        page_no=1,
        num_of_rows=10,
    )

    for warehouse in result["items"]:
        print(
            warehouse["company_name"],
            "|",
            warehouse["storage_item"],
            "|",
            warehouse["warehouse_no"],
        )
