# 이 파일을 secret_config.py로 복사한 뒤 실제 AppKey를 입력하세요.
# secret_config.py는 Git이나 과제 제출 파일에 포함하지 마세요.

TMAP_APP_KEY = "i0s4NANaAq9GNbPdS7tAm2sblnQja8wI1KSC5gzD"
