-- ============================================================
-- SafeLogi AI
-- 4-2. 회원가입 이후 실제 운행 과정에서 축적되는 데이터
--
-- 핵심 원리
--
-- 1. TRIP
--    한 번의 운행 전체를 나타내는 부모 데이터
--
-- 2. TRIP_ROUTE_SEGMENT
--    하나의 운행을 여러 지역/도로 구간으로 나눈 상세 데이터
--
-- 3. DRIVER_ROUTE_HISTORY
--    여러 TRIP 데이터를 운전자/경로별로 집계한 분석 데이터
--
-- 관계:
--
-- DRIVER
--   │
--   └──── TRIP
--           │
--           ├──── TRIP_ROUTE_SEGMENT
--           │
--           └──── DRIVER_ROUTE_HISTORY의 계산 원본
--
-- 즉,
-- 운행 원본 → 구간별 위험 분석 → 반복 운행 통계
-- 순서로 데이터가 만들어진다.
-- ============================================================



-- ============================================================
-- 1. TRIP
-- 운행 기본정보
-- ============================================================

CREATE TABLE IF NOT EXISTS trip (

    -- 각 운행을 고유하게 식별하기 위한 PK
    -- 배송 한 번, 운행 한 번마다 새로운 trip_id가 생성된다.
    trip_id BIGSERIAL PRIMARY KEY,

    -- 어떤 물류회사의 운행인지 연결
    company_id BIGINT NOT NULL
        REFERENCES company(company_id)
        ON DELETE CASCADE,

    -- 실제 운전한 운전자
    driver_id BIGINT NOT NULL
        REFERENCES driver(driver_id),

    -- 해당 운행에서 사용한 차량
    vehicle_id BIGINT NOT NULL
        REFERENCES vehicle(vehicle_id),

    -- 출발/도착 물류센터가 등록되어 있는 경우 사용
    -- 일반 주소 운행도 가능하므로 NULL 허용
    origin_center_id BIGINT
        REFERENCES logistics_center(center_id),

    destination_center_id BIGINT
        REFERENCES logistics_center(center_id),

    -- 실제 출발지와 목적지
    -- TMAP 경로 검색에도 사용할 수 있다.
    origin TEXT NOT NULL,
    destination TEXT NOT NULL,

    -- 실제 출발 시각
    departure_time TIMESTAMPTZ,

    -- 실제 도착 시각
    arrival_time TIMESTAMPTZ,

    -- 출발 전에 TMAP 등이 계산한 예상 소요시간
    -- 단위: 분
    predicted_duration_minutes INTEGER,

    -- 운행 종료 후 실제 소요시간
    -- 단위: 분
    actual_duration_minutes INTEGER,

    -- 해당 운행에서 운반한 화물 종류
    cargo_type VARCHAR(100),

    -- 실제 적재량
    -- 차량 자체의 최대 적재량과 구분한다.
    cargo_weight_kg NUMERIC(12, 2),

    -- 실제 사고 발생 여부
    -- 향후 AI 예측 결과와 실제 사고의 관계를 분석할 때 사용
    actual_accident BOOLEAN NOT NULL DEFAULT FALSE,

    -- 운행 상태
    -- 예:
    -- PLANNED    = 운행 예정
    -- DRIVING    = 운행 중
    -- COMPLETED  = 운행 완료
    -- CANCELLED  = 운행 취소
    trip_status VARCHAR(30) NOT NULL DEFAULT 'PLANNED',

    -- 데이터 생성 시각
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- 예상 운행시간은 음수가 될 수 없다.
    CONSTRAINT chk_trip_predicted_duration
        CHECK (
            predicted_duration_minutes IS NULL
            OR predicted_duration_minutes >= 0
        ),

    -- 실제 운행시간도 음수가 될 수 없다.
    CONSTRAINT chk_trip_actual_duration
        CHECK (
            actual_duration_minutes IS NULL
            OR actual_duration_minutes >= 0
        ),

    -- 적재중량도 음수가 될 수 없다.
    CONSTRAINT chk_trip_cargo_weight
        CHECK (
            cargo_weight_kg IS NULL
            OR cargo_weight_kg >= 0
        ),

    -- 도착시간이 출발시간보다 앞설 수 없도록 검사
    CONSTRAINT chk_trip_time_order
        CHECK (
            arrival_time IS NULL
            OR departure_time IS NULL
            OR arrival_time >= departure_time
        )
);


COMMENT ON TABLE trip IS
'한 번의 물류차량 운행 전체 정보를 저장하는 핵심 테이블';

COMMENT ON COLUMN trip.trip_id IS
'운행 고유 ID';

COMMENT ON COLUMN trip.company_id IS
'운행을 수행한 물류기업 ID';

COMMENT ON COLUMN trip.driver_id IS
'운행 담당 운전자 ID';

COMMENT ON COLUMN trip.vehicle_id IS
'운행에 사용된 차량 ID';

COMMENT ON COLUMN trip.origin IS
'운행 출발지';

COMMENT ON COLUMN trip.destination IS
'운행 목적지';

COMMENT ON COLUMN trip.departure_time IS
'실제 출발시간';

COMMENT ON COLUMN trip.arrival_time IS
'실제 도착시간';

COMMENT ON COLUMN trip.predicted_duration_minutes IS
'TMAP 등에서 계산한 예상 운행시간(분)';

COMMENT ON COLUMN trip.actual_duration_minutes IS
'실제 운행 소요시간(분)';

COMMENT ON COLUMN trip.actual_accident IS
'해당 운행 중 실제 사고 발생 여부';



-- ============================================================
-- 2. TRIP_ROUTE_SEGMENT
-- 운행 경로를 여러 구간으로 나눈 위험 분석 정보
-- ============================================================

CREATE TABLE IF NOT EXISTS trip_route_segment (

    -- 각 경로 구간의 고유 ID
    segment_id BIGSERIAL PRIMARY KEY,

    -- 어떤 운행에 속한 구간인지 연결
    -- 하나의 TRIP에 여러 SEGMENT가 존재한다.
    trip_id BIGINT NOT NULL
        REFERENCES trip(trip_id)
        ON DELETE CASCADE,

    -- 경로에서 몇 번째 구간인지 저장
    -- 1 → 2 → 3 → ... 순으로 진행
    segment_order INTEGER NOT NULL,

    -- 해당 구간이 위치한 행정지역
    -- 예: 서울특별시 강남구
    region VARCHAR(100),

    -- 도로 종류
    -- 예: 일반도로 / 고속도로 등
    road_type VARCHAR(100),

    -- 해당 구간에 진입할 것으로 예상되는 시간
    entry_time TIMESTAMPTZ,

    -- 해당 구간 거리
    -- 단위: km
    distance_km NUMERIC(10, 3),

    -- TMAP 실시간 교통정보 기반 혼잡도
    congestion_level VARCHAR(30),

    -- 해당 구간 평균 교통속도
    -- 단위: km/h
    average_speed_kmh NUMERIC(8, 2),

    -- 위험도 계산 당시 날씨
    weather VARCHAR(50),

    -- 위험도 계산 당시 시간대
    -- 예: 새벽 / 오전 / 오후 / 야간
    time_band VARCHAR(50),

    -- SafeLogi AI에서 계산한 0~100 위험점수
    risk_score NUMERIC(6, 2),

    -- 위험점수를 사람이 이해하기 쉽게 분류
    -- 예: 낮음 / 보통 / 높음 / 매우 높음
    risk_level VARCHAR(30),

    -- 기준 위험 대비 상대적인 위험 수준
    -- 개인 사고확률이 아니라 상대위험 지표
    relative_risk NUMERIC(10, 4),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- 하나의 운행 안에서 동일한 segment_order를
    -- 두 번 저장하지 못하도록 방지
    CONSTRAINT uq_trip_segment_order
        UNIQUE (trip_id, segment_order),

    CONSTRAINT chk_segment_order
        CHECK (segment_order > 0),

    CONSTRAINT chk_segment_distance
        CHECK (
            distance_km IS NULL
            OR distance_km >= 0
        ),

    CONSTRAINT chk_segment_speed
        CHECK (
            average_speed_kmh IS NULL
            OR average_speed_kmh >= 0
        ),

    -- 위험점수는 0~100 범위
    CONSTRAINT chk_segment_risk_score
        CHECK (
            risk_score IS NULL
            OR risk_score BETWEEN 0 AND 100
        ),

    CONSTRAINT chk_segment_relative_risk
        CHECK (
            relative_risk IS NULL
            OR relative_risk >= 0
        )
);


COMMENT ON TABLE trip_route_segment IS
'한 번의 운행 경로를 여러 지역·도로 구간으로 나누어 교통·날씨·AI 위험정보를 저장';

COMMENT ON COLUMN trip_route_segment.segment_order IS
'운행 경로에서 구간이 나타나는 순서';

COMMENT ON COLUMN trip_route_segment.region IS
'해당 경로 구간의 지역';

COMMENT ON COLUMN trip_route_segment.road_type IS
'해당 구간의 도로 종류';

COMMENT ON COLUMN trip_route_segment.entry_time IS
'해당 구간 진입 예상시간';

COMMENT ON COLUMN trip_route_segment.congestion_level IS
'실시간 교통 혼잡 수준';

COMMENT ON COLUMN trip_route_segment.average_speed_kmh IS
'해당 구간 평균 교통속도(km/h)';

COMMENT ON COLUMN trip_route_segment.risk_score IS
'SafeLogi AI가 계산한 0~100 위험점수';

COMMENT ON COLUMN trip_route_segment.risk_level IS
'낮음·보통·높음·매우 높음 등의 위험등급';

COMMENT ON COLUMN trip_route_segment.relative_risk IS
'기준 위험 대비 상대위험도이며 개인 사고확률을 의미하지 않음';



-- ============================================================
-- 3. DRIVER_ROUTE_HISTORY
-- 운전자별 반복 운행 경로 통계
-- ============================================================
--
-- 중요:
--
-- 이 테이블은 사용자가 직접 입력하는 원본 데이터라기보다
--
-- TRIP
-- +
-- TRIP_ROUTE_SEGMENT
-- +
-- 실제 사고 기록
--
-- 을 이용해 서버가 계산한 "집계 데이터"를 저장하는 테이블이다.
--
-- 예:
--
-- 운전자 10번
-- 서울센터 → 평택센터
--
-- 총 운행      37회
-- 평균 위험점수 58.4
-- 최고 위험점수 84.2
-- 평균 소요시간 73분
-- 실제 사고      1회
--
-- 같은 결과를 저장한다.
-- ============================================================

CREATE TABLE IF NOT EXISTS driver_route_history (

    -- 집계 결과 자체의 고유 ID
    history_id BIGSERIAL PRIMARY KEY,

    -- 어느 운전자의 반복 운행인지 연결
    driver_id BIGINT NOT NULL
        REFERENCES driver(driver_id)
        ON DELETE CASCADE,

    -- 어느 회사에서 발생한 운행인지도 함께 저장
    -- 관리자 대시보드에서 회사별 통계를 빠르게 조회하기 위함
    company_id BIGINT NOT NULL
        REFERENCES company(company_id)
        ON DELETE CASCADE,

    -- 반복 운행의 대표 출발지
    origin TEXT NOT NULL,

    -- 반복 운행의 대표 목적지
    destination TEXT NOT NULL,

    -- 해당 운전자가 이 경로를 운행한 총 횟수
    route_count INTEGER NOT NULL DEFAULT 0,

    -- 이 경로의 과거 운행 위험점수 평균
    avg_risk_score NUMERIC(6, 2),

    -- 지금까지 이 경로에서 측정된 가장 높은 위험점수
    max_risk_score NUMERIC(6, 2),

    -- 실제 평균 운행시간
    -- 단위: 분
    avg_travel_time_minutes NUMERIC(10, 2),

    -- 해당 운전자·경로에서 발생한 실제 사고 횟수
    accident_count INTEGER NOT NULL DEFAULT 0,

    -- 마지막으로 해당 경로를 운행한 시각
    last_driven_at TIMESTAMPTZ,

    -- 집계 결과를 마지막으로 계산한 시각
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_history_route_count
        CHECK (route_count >= 0),

    CONSTRAINT chk_history_avg_risk
        CHECK (
            avg_risk_score IS NULL
            OR avg_risk_score BETWEEN 0 AND 100
        ),

    CONSTRAINT chk_history_max_risk
        CHECK (
            max_risk_score IS NULL
            OR max_risk_score BETWEEN 0 AND 100
        ),

    CONSTRAINT chk_history_travel_time
        CHECK (
            avg_travel_time_minutes IS NULL
            OR avg_travel_time_minutes >= 0
        ),

    CONSTRAINT chk_history_accident_count
        CHECK (accident_count >= 0),

    -- 같은 운전자 + 같은 출발지 + 같은 목적지에 대해서는
    -- 하나의 집계 레코드만 유지
    CONSTRAINT uq_driver_route_history
        UNIQUE (
            driver_id,
            origin,
            destination
        )
);


COMMENT ON TABLE driver_route_history IS
'TRIP 및 경로 위험 데이터를 운전자·경로별로 집계한 반복운행 분석 테이블';

COMMENT ON COLUMN driver_route_history.route_count IS
'운전자가 동일 출발지·목적지 경로를 운행한 누적 횟수';

COMMENT ON COLUMN driver_route_history.avg_risk_score IS
'해당 반복 경로의 평균 AI 위험점수';

COMMENT ON COLUMN driver_route_history.max_risk_score IS
'해당 반복 경로에서 기록된 최고 AI 위험점수';

COMMENT ON COLUMN driver_route_history.avg_travel_time_minutes IS
'동일 경로의 평균 실제 소요시간(분)';

COMMENT ON COLUMN driver_route_history.accident_count IS
'해당 운전자·경로에서 기록된 실제 사고 누적 횟수';

COMMENT ON COLUMN driver_route_history.last_driven_at IS
'운전자가 해당 경로를 마지막으로 운행한 시각';



-- ============================================================
-- 조회 속도 향상을 위한 INDEX
-- ============================================================

-- 회사별 운행 조회
CREATE INDEX IF NOT EXISTS idx_trip_company
ON trip(company_id);


-- 운전자별 운행 조회
CREATE INDEX IF NOT EXISTS idx_trip_driver
ON trip(driver_id);


-- 차량별 운행 조회
CREATE INDEX IF NOT EXISTS idx_trip_vehicle
ON trip(vehicle_id);


-- 최근 운행 검색
CREATE INDEX IF NOT EXISTS idx_trip_departure_time
ON trip(departure_time);


-- 특정 운행의 경로 구간 검색
CREATE INDEX IF NOT EXISTS idx_segment_trip
ON trip_route_segment(trip_id);


-- 운전자별 반복경로 조회
CREATE INDEX IF NOT EXISTS idx_route_history_driver
ON driver_route_history(driver_id);


-- 회사 관리자용 반복경로 조회
CREATE INDEX IF NOT EXISTS idx_route_history_company
ON driver_route_history(company_id);



-- ============================================================
-- 생성 확인
-- ============================================================

SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN (
      'trip',
      'trip_route_segment',
      'driver_route_history'
  )
ORDER BY table_name;