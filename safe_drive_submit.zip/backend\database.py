from __future__ import annotations

import os
from typing import Any

import psycopg2
from psycopg2.extras import RealDictCursor


# ============================================================
# SafeLogi AI - PostgreSQL 연결 설정
#
# 실제 비밀번호를 코드에 직접 적지 않고 환경변수로 받습니다.
#
# PowerShell 예시:
# $env:SAFELOGI_DB_PASSWORD="본인의 PostgreSQL 비밀번호"
# ============================================================

DB_HOST = os.getenv("SAFELOGI_DB_HOST", "localhost")
DB_PORT = int(os.getenv("SAFELOGI_DB_PORT", "5432"))
DB_NAME = os.getenv("SAFELOGI_DB_NAME", "safelogi")
DB_USER = os.getenv("SAFELOGI_DB_USER", "postgres")
DB_PASSWORD = os.getenv("SAFELOGI_DB_PASSWORD", "")


def get_connection():
    """PostgreSQL safelogi 데이터베이스 연결을 생성한다."""
    if not DB_PASSWORD:
        raise RuntimeError(
            "SAFELOGI_DB_PASSWORD 환경변수가 설정되지 않았습니다."
        )

    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
    )


def fetch_companies() -> list[dict[str, Any]]:
    """등록된 물류회사 목록을 조회한다."""
    sql = """
        SELECT
            company_id,
            company_name,
            business_type,
            main_cargo_type,
            created_at
        FROM company
        ORDER BY company_id;
    """

    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(sql)
            return [dict(row) for row in cursor.fetchall()]


def fetch_drivers(company_id: int) -> list[dict[str, Any]]:
    """특정 회사에 소속된 운전자 목록을 조회한다."""
    sql = """
        SELECT
            driver_id,
            company_id,
            driver_name,
            age,
            driving_experience,
            license_type,
            active
        FROM driver
        WHERE company_id = %s
        ORDER BY driver_id;
    """

    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(sql, (company_id,))
            return [dict(row) for row in cursor.fetchall()]


def fetch_vehicles(company_id: int) -> list[dict[str, Any]]:
    """특정 회사에 등록된 차량 목록을 조회한다."""
    sql = """
        SELECT
            vehicle_id,
            company_id,
            license_plate,
            vehicle_type,
            vehicle_model,
            model_year,
            max_load_weight_kg,
            vehicle_status
        FROM vehicle
        WHERE company_id = %s
        ORDER BY vehicle_id;
    """

    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(sql, (company_id,))
            return [dict(row) for row in cursor.fetchall()]


def fetch_trip_summary(trip_id: int) -> list[dict[str, Any]]:
    """
    한 번의 운행에 대해
    기업 + 운전자 + 차량 + 경로 구간 + 위험정보를 JOIN해서 조회한다.
    """
    sql = """
        SELECT
            c.company_name,
            d.driver_name,
            v.vehicle_model,
            v.license_plate,
            t.trip_id,
            t.origin,
            t.destination,
            t.predicted_duration_minutes,
            t.actual_duration_minutes,
            t.actual_accident,
            t.trip_status,
            s.segment_order,
            s.region,
            s.road_type,
            s.congestion_level,
            s.average_speed_kmh,
            s.weather,
            s.time_band,
            s.risk_score,
            s.risk_level,
            s.relative_risk
        FROM trip t
        JOIN company c
            ON t.company_id = c.company_id
        JOIN driver d
            ON t.driver_id = d.driver_id
        JOIN vehicle v
            ON t.vehicle_id = v.vehicle_id
        JOIN trip_route_segment s
            ON t.trip_id = s.trip_id
        WHERE t.trip_id = %s
        ORDER BY s.segment_order;
    """

    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(sql, (trip_id,))
            return [dict(row) for row in cursor.fetchall()]


def fetch_route_history(driver_id: int) -> list[dict[str, Any]]:
    """특정 운전자의 반복 경로 통계를 조회한다."""
    sql = """
        SELECT
            history_id,
            driver_id,
            company_id,
            origin,
            destination,
            route_count,
            avg_risk_score,
            max_risk_score,
            avg_travel_time_minutes,
            accident_count,
            last_driven_at
        FROM driver_route_history
        WHERE driver_id = %s
        ORDER BY last_driven_at DESC NULLS LAST;
    """

    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(sql, (driver_id,))
            return [dict(row) for row in cursor.fetchall()]


def print_test_result() -> None:
    """
    database.py를 직접 실행했을 때 사용하는 DB 연결 테스트.

    현재 테스트 데이터 기준:
        company_id = 2 : 세이프물류
        driver_id  = 3 : 김안전
        trip_id    = 1 : 서울물류센터 -> 평택물류센터
    """

    print("=" * 60)
    print("SafeLogi PostgreSQL 연결 테스트")
    print("=" * 60)

    print("\n[1] 기업 목록")
    for company in fetch_companies():
        print(company)

    print("\n[2] 세이프물류 운전자 목록 (company_id=2)")
    for driver in fetch_drivers(2):
        print(driver)

    print("\n[3] 세이프물류 차량 목록 (company_id=2)")
    for vehicle in fetch_vehicles(2):
        print(vehicle)

    print("\n[4] 테스트 운행 및 경로 위험정보 (trip_id=1)")
    trip_rows = fetch_trip_summary(1)

    if not trip_rows:
        print("trip_id=1 운행 데이터가 없습니다.")
    else:
        for row in trip_rows:
            print(
                f"{row['company_name']} | "
                f"{row['driver_name']} | "
                f"{row['vehicle_model']} | "
                f"{row['origin']} -> {row['destination']} | "
                f"{row['region']} | "
                f"위험점수={row['risk_score']} | "
                f"등급={row['risk_level']}"
            )

    print("\n[5] 김안전 반복경로 통계 (driver_id=3)")
    for history in fetch_route_history(3):
        print(history)

    print("\nDB 조회 테스트 완료")


if __name__ == "__main__":
    print_test_result()
