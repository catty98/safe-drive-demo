import sqlite3

# 1. 데이터베이스 연결 (없으면 자동 생성)
conn = sqlite3.connect("transport_safety.db")
cursor = conn.cursor()

# 외래키 제약조건 활성화 (SQLite 필수 설정)
cursor.execute("PRAGMA foreign_keys = ON;")

# -------------------------------------------------------------
# [카테고리 1] DRIVER_SAFETY_INFO (운행별 실시간 안전 정보)
# -------------------------------------------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS DRIVER_SAFETY_INFO (
    trip_id TEXT PRIMARY KEY,
    current_region TEXT NOT NULL,
    high_risk_region TEXT,
    eta_minutes INTEGER,
    risk_score REAL,
    risk_level TEXT,
    relative_risk TEXT,
    congestion_level TEXT,
    weather TEXT,
    time_band TEXT,
    major_accident_type TEXT,
    safety_message TEXT
)
""")

# -------------------------------------------------------------
# [카테고리 2] SAFE_ROUTE_RECOMMENDATION (안전 경로 추천 정보)
# -------------------------------------------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS SAFE_ROUTE_RECOMMENDATION (
    route_id TEXT PRIMARY KEY,
    trip_id TEXT NOT NULL,
    route_type TEXT,
    total_distance REAL,
    expected_duration INTEGER,
    route_risk_score REAL,
    high_risk_segment_count INTEGER,
    congestion_segment_count INTEGER,
    recommendation TEXT,
    FOREIGN KEY (trip_id) REFERENCES DRIVER_SAFETY_INFO(trip_id) ON DELETE CASCADE
)
""")

# -------------------------------------------------------------
# [카테고리 3] FLEET_SAFETY_REPORT (물류회사 관리자용 운행 분석정보)
# -------------------------------------------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS FLEET_SAFETY_REPORT (
    report_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    driver_id TEXT NOT NULL,
    vehicle_id TEXT NOT NULL,
    total_trip_count INTEGER,
    avg_risk_score REAL,
    high_risk_trip_count INTEGER,
    accident_count INTEGER,
    frequent_high_risk_region TEXT,
    frequent_route TEXT,
    avg_actual_duration REAL,
    generated_at TEXT
)
""")

# 변경사항 저장 및 연결 종료
conn.commit()
conn.close()

print("모든 테이블(DRIVER_SAFETY_INFO, SAFE_ROUTE_RECOMMENDATION, FLEET_SAFETY_REPORT)이 성공적으로 생성되었습니다!")
