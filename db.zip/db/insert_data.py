import sqlite3

def insert_data():
    # 데이터베이스 연결
    conn = sqlite3.connect("transport_safety.db")
    cursor = conn.cursor()
    cursor.execute("PRAGMA foreign_keys = ON;")

    try:
        # 1. DRIVER_SAFETY_INFO 데이터 삽입
        driver_info = [
            ("TRIP_001", "강남구", "○○시 구간", 15, 8.5, "높음", "높음", "심각", "흐림", "퇴근시간", "추돌", "정체구간 진입 전 차간 거리를 충분히 확보하세요."),
            ("TRIP_002", "서초구", "△△로", 5, 2.1, "낮음", "낮음", "원활", "맑음", "출근시간", "없음", "안전 운행 중입니다.")
        ]
        cursor.executemany("INSERT OR IGNORE INTO DRIVER_SAFETY_INFO VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", driver_info)

        # 2. SAFE_ROUTE_RECOMMENDATION 데이터 삽입
        # trip_id가 DRIVER_SAFETY_INFO에 존재해야 함
        route_rec = [
            ("ROUTE_001", "TRIP_001", "추천 경로", 12.5, 20, 2.5, 0, 1, "권장")
        ]
        cursor.executemany("INSERT OR IGNORE INTO SAFE_ROUTE_RECOMMENDATION VALUES (?,?,?,?,?,?,?,?,?)", route_rec)

        # 3. FLEET_SAFETY_REPORT 데이터 삽입
        fleet_report = [
            ("REP_001", "COMP_LOGIS_01", "DRV_KIM_01", "VEH_1234", 150, 4.2, 3, 0, "강남구", "강남대로-테헤란로", 42.5, "2026-08-12")
        ]
        cursor.executemany("INSERT OR IGNORE INTO FLEET_SAFETY_REPORT VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", fleet_report)

        conn.commit()
        print("모든 테이블에 데이터 삽입 완료!")

    except sqlite3.Error as e:
        print(f"오류 발생: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    insert_data()