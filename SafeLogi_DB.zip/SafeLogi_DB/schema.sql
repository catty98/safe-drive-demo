PRAGMA foreign_keys = ON;

-- =====================================================
-- 1. 기업 정보
-- =====================================================
CREATE TABLE IF NOT EXISTS company (
    company_id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_name TEXT NOT NULL,
    business_type TEXT,
    main_cargo_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- 2. 물류센터 정보
-- =====================================================
CREATE TABLE IF NOT EXISTS logistics_center (
    center_id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    center_name TEXT NOT NULL,
    address TEXT NOT NULL,
    latitude REAL,
    longitude REAL,
    open_time TEXT,
    close_time TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (company_id)
        REFERENCES company(company_id)
        ON DELETE CASCADE
);

-- =====================================================
-- 3. 운전자 정보
-- =====================================================
CREATE TABLE IF NOT EXISTS driver (
    driver_id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    driver_name TEXT NOT NULL,
    age INTEGER,
    driving_experience INTEGER,
    license_type TEXT,
    accident_history_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (company_id)
        REFERENCES company(company_id)
        ON DELETE CASCADE
);

-- =====================================================
-- 4. 차량 정보
-- =====================================================
CREATE TABLE IF NOT EXISTS vehicle (
    vehicle_id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    vehicle_number TEXT NOT NULL,
    vehicle_type TEXT,
    vehicle_model TEXT,
    model_year INTEGER,
    max_load_weight REAL,
    default_cargo_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (company_id)
        REFERENCES company(company_id)
        ON DELETE CASCADE
);

-- =====================================================
-- 5. 운전자 - 차량 배정 관계
-- =====================================================
CREATE TABLE IF NOT EXISTS driver_vehicle_assignment (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    driver_id INTEGER NOT NULL,
    vehicle_id INTEGER NOT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    released_at DATETIME,
    active INTEGER DEFAULT 1 CHECK (active IN (0, 1)),

    FOREIGN KEY (driver_id)
        REFERENCES driver(driver_id)
        ON DELETE CASCADE,

    FOREIGN KEY (vehicle_id)
        REFERENCES vehicle(vehicle_id)
        ON DELETE CASCADE
);
