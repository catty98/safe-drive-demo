from database import (
    initialize_database,
    add_company,
    add_logistics_center,
    add_driver,
    add_vehicle,
    assign_vehicle,
    get_companies,
    get_centers,
    get_drivers,
    get_vehicles,
    get_assignments,
    company_exists,
    driver_exists,
    vehicle_exists,
    delete_company,
    delete_center,
    delete_driver,
    delete_vehicle,
    delete_assignment,
)


# =====================================================
# 입력 보조 함수
# =====================================================
def input_int(message, allow_empty=False):
    while True:
        value = input(message).strip()

        if allow_empty and value == "":
            return None

        try:
            return int(value)
        except ValueError:
            print("숫자를 입력해 주세요.")


def input_float(message, allow_empty=False):
    while True:
        value = input(message).strip()

        if allow_empty and value == "":
            return None

        try:
            return float(value)
        except ValueError:
            print("숫자를 입력해 주세요.")


# =====================================================
# 목록 출력 함수
# =====================================================
def show_companies():
    companies = get_companies()

    print("\n[등록 기업]")

    if not companies:
        print("등록된 기업이 없습니다.")
        return False

    for company in companies:
        print(
            f"{company['company_id']} | "
            f"{company['company_name']} | "
            f"{company['business_type'] or '-'} | "
            f"{company['main_cargo_type'] or '-'}"
        )

    return True


def show_drivers():
    drivers = get_drivers()

    print("\n[운전자 목록]")

    if not drivers:
        print("등록된 운전자가 없습니다.")
        return False

    for driver in drivers:
        print(
            f"{driver['driver_id']} | "
            f"{driver['company_name']} | "
            f"{driver['driver_name']}"
        )

    return True


def show_vehicles():
    vehicles = get_vehicles()

    print("\n[차량 목록]")

    if not vehicles:
        print("등록된 차량이 없습니다.")
        return False

    for vehicle in vehicles:
        print(
            f"{vehicle['vehicle_id']} | "
            f"{vehicle['company_name']} | "
            f"{vehicle['vehicle_number']} | "
            f"{vehicle['vehicle_type'] or '-'}"
        )

    return True


# =====================================================
# 등록 기능
# =====================================================
def register_company():
    print("\n[기업 등록]")

    company_name = input("기업명: ").strip()

    if not company_name:
        print("기업명은 반드시 입력해야 합니다.")
        return

    business_type = input("업종: ").strip()
    main_cargo_type = input("주요 적재물 종류: ").strip()

    company_id = add_company(
        company_name,
        business_type,
        main_cargo_type,
    )

    print(f"\n기업 등록 완료 (company_id={company_id})")


def register_center():
    if not show_companies():
        print("먼저 기업을 등록해 주세요.")
        return

    company_id = input_int("\n소속 기업 ID: ")

    if not company_exists(company_id):
        print("존재하지 않는 기업 ID입니다.")
        return

    center_name = input("물류센터명: ").strip()
    address = input("주소: ").strip()

    if not center_name or not address:
        print("물류센터명과 주소는 반드시 입력해야 합니다.")
        return

    latitude = input_float(
        "위도 (모르면 Enter): ",
        allow_empty=True,
    )
    longitude = input_float(
        "경도 (모르면 Enter): ",
        allow_empty=True,
    )
    open_time = input("운영 시작시간 (예: 08:00): ").strip()
    close_time = input("운영 종료시간 (예: 18:00): ").strip()

    center_id = add_logistics_center(
        company_id,
        center_name,
        address,
        latitude,
        longitude,
        open_time,
        close_time,
    )

    print(f"\n물류센터 등록 완료 (center_id={center_id})")


def register_driver():
    if not show_companies():
        print("먼저 기업을 등록해 주세요.")
        return

    company_id = input_int("\n소속 기업 ID: ")

    if not company_exists(company_id):
        print("존재하지 않는 기업 ID입니다.")
        return

    driver_name = input("운전자 이름: ").strip()

    if not driver_name:
        print("운전자 이름은 반드시 입력해야 합니다.")
        return

    age = input_int("나이 (모르면 Enter): ", allow_empty=True)
    driving_experience = input_int(
        "운전 경력(년) (모르면 Enter): ",
        allow_empty=True,
    )
    license_type = input("면허 종류: ").strip()
    accident_history_count = input_int(
        "과거 사고 횟수 (없으면 0): "
    )

    if accident_history_count < 0:
        print("과거 사고 횟수는 0 이상이어야 합니다.")
        return

    driver_id = add_driver(
        company_id,
        driver_name,
        age,
        driving_experience,
        license_type,
        accident_history_count,
    )

    print(f"\n운전자 등록 완료 (driver_id={driver_id})")


def register_vehicle():
    if not show_companies():
        print("먼저 기업을 등록해 주세요.")
        return

    company_id = input_int("\n소속 기업 ID: ")

    if not company_exists(company_id):
        print("존재하지 않는 기업 ID입니다.")
        return

    vehicle_number = input("차량 번호: ").strip()

    if not vehicle_number:
        print("차량 번호는 반드시 입력해야 합니다.")
        return

    vehicle_type = input("차량 종류: ").strip()
    vehicle_model = input("차량 모델: ").strip()
    model_year = input_int(
        "차량 연식 (모르면 Enter): ",
        allow_empty=True,
    )
    max_load_weight = input_float(
        "최대 적재 가능 중량(kg) (모르면 Enter): ",
        allow_empty=True,
    )
    default_cargo_type = input("주요 적재물 종류: ").strip()

    vehicle_id = add_vehicle(
        company_id,
        vehicle_number,
        vehicle_type,
        vehicle_model,
        model_year,
        max_load_weight,
        default_cargo_type,
    )

    print(f"\n차량 등록 완료 (vehicle_id={vehicle_id})")


def register_assignment():
    if not show_drivers():
        print("먼저 운전자를 등록해 주세요.")
        return

    if not show_vehicles():
        print("먼저 차량을 등록해 주세요.")
        return

    driver_id = input_int("\n운전자 ID: ")

    if not driver_exists(driver_id):
        print("존재하지 않는 운전자 ID입니다.")
        return

    vehicle_id = input_int("차량 ID: ")

    if not vehicle_exists(vehicle_id):
        print("존재하지 않는 차량 ID입니다.")
        return

    assignment_id = assign_vehicle(driver_id, vehicle_id)

    print(f"\n차량 배정 완료 (assignment_id={assignment_id})")


# =====================================================
# 전체 데이터 조회
# =====================================================
def show_all_data():
    print("\n==============================")
    print("기업")
    print("==============================")
    companies = get_companies()
    if not companies:
        print("등록된 기업이 없습니다.")
    else:
        for row in companies:
            print(
                f"ID={row['company_id']} | "
                f"기업명={row['company_name']} | "
                f"업종={row['business_type'] or '-'} | "
                f"주요 적재물={row['main_cargo_type'] or '-'}"
            )

    print("\n==============================")
    print("물류센터")
    print("==============================")
    centers = get_centers()
    if not centers:
        print("등록된 물류센터가 없습니다.")
    else:
        for row in centers:
            print(
                f"ID={row['center_id']} | "
                f"기업={row['company_name']} | "
                f"센터={row['center_name']} | "
                f"주소={row['address']} | "
                f"운영시간={row['open_time'] or '-'}~{row['close_time'] or '-'}"
            )

    print("\n==============================")
    print("운전자")
    print("==============================")
    drivers = get_drivers()
    if not drivers:
        print("등록된 운전자가 없습니다.")
    else:
        for row in drivers:
            print(
                f"ID={row['driver_id']} | "
                f"기업={row['company_name']} | "
                f"이름={row['driver_name']} | "
                f"나이={row['age'] if row['age'] is not None else '-'} | "
                f"경력={row['driving_experience'] if row['driving_experience'] is not None else '-'}년 | "
                f"면허={row['license_type'] or '-'} | "
                f"사고이력={row['accident_history_count']}회"
            )

    print("\n==============================")
    print("차량")
    print("==============================")
    vehicles = get_vehicles()
    if not vehicles:
        print("등록된 차량이 없습니다.")
    else:
        for row in vehicles:
            print(
                f"ID={row['vehicle_id']} | "
                f"기업={row['company_name']} | "
                f"차량번호={row['vehicle_number']} | "
                f"종류={row['vehicle_type'] or '-'} | "
                f"모델={row['vehicle_model'] or '-'} | "
                f"연식={row['model_year'] if row['model_year'] is not None else '-'}"
            )

    print("\n==============================")
    print("차량 배정")
    print("==============================")
    assignments = get_assignments()
    if not assignments:
        print("등록된 차량 배정이 없습니다.")
    else:
        for row in assignments:
            print(
                f"ID={row['assignment_id']} | "
                f"기업={row['company_name']} | "
                f"운전자={row['driver_name']} | "
                f"차량={row['vehicle_number']} | "
                f"상태={'활성' if row['active'] else '종료'}"
            )


# =====================================================
# 삭제 기능
# =====================================================
def confirm_delete(message):
    answer = input(f"{message} (y/n): ").strip().lower()
    return answer == "y"


def remove_company():
    if not show_companies():
        return

    company_id = input_int("\n삭제할 기업 ID: ")

    if not company_exists(company_id):
        print("존재하지 않는 기업 ID입니다.")
        return

    print(
        "\n주의: 기업을 삭제하면 해당 기업의 물류센터, 운전자, "
        "차량 및 차량 배정 정보도 함께 삭제됩니다."
    )

    if not confirm_delete("정말 삭제하시겠습니까?"):
        print("삭제를 취소했습니다.")
        return

    if delete_company(company_id):
        print("기업을 삭제했습니다.")
    else:
        print("기업 삭제에 실패했습니다.")


def remove_center():
    centers = get_centers()

    print("\n[물류센터 목록]")

    if not centers:
        print("등록된 물류센터가 없습니다.")
        return

    for center in centers:
        print(
            f"{center['center_id']} | "
            f"{center['company_name']} | "
            f"{center['center_name']}"
        )

    center_id = input_int("\n삭제할 물류센터 ID: ")

    if not confirm_delete("정말 삭제하시겠습니까?"):
        print("삭제를 취소했습니다.")
        return

    if delete_center(center_id):
        print("물류센터를 삭제했습니다.")
    else:
        print("해당 물류센터 ID가 존재하지 않습니다.")


def remove_driver():
    if not show_drivers():
        return

    driver_id = input_int("\n삭제할 운전자 ID: ")

    if not driver_exists(driver_id):
        print("존재하지 않는 운전자 ID입니다.")
        return

    print("운전자를 삭제하면 해당 운전자의 차량 배정 정보도 함께 삭제됩니다.")

    if not confirm_delete("정말 삭제하시겠습니까?"):
        print("삭제를 취소했습니다.")
        return

    if delete_driver(driver_id):
        print("운전자를 삭제했습니다.")
    else:
        print("운전자 삭제에 실패했습니다.")


def remove_vehicle():
    if not show_vehicles():
        return

    vehicle_id = input_int("\n삭제할 차량 ID: ")

    if not vehicle_exists(vehicle_id):
        print("존재하지 않는 차량 ID입니다.")
        return

    print("차량을 삭제하면 해당 차량의 운전자 배정 정보도 함께 삭제됩니다.")

    if not confirm_delete("정말 삭제하시겠습니까?"):
        print("삭제를 취소했습니다.")
        return

    if delete_vehicle(vehicle_id):
        print("차량을 삭제했습니다.")
    else:
        print("차량 삭제에 실패했습니다.")


def remove_assignment():
    assignments = get_assignments()

    print("\n[차량 배정 목록]")

    if not assignments:
        print("등록된 차량 배정이 없습니다.")
        return

    for assignment in assignments:
        print(
            f"{assignment['assignment_id']} | "
            f"{assignment['company_name']} | "
            f"{assignment['driver_name']} | "
            f"{assignment['vehicle_number']}"
        )

    assignment_id = input_int("\n삭제할 배정 ID: ")

    if not confirm_delete("정말 삭제하시겠습니까?"):
        print("삭제를 취소했습니다.")
        return

    if delete_assignment(assignment_id):
        print("차량 배정 정보를 삭제했습니다.")
    else:
        print("해당 배정 ID가 존재하지 않습니다.")


def delete_menu():
    while True:
        print(
            "\n"
            "============================\n"
            " 데이터 삭제\n"
            "============================\n"
            "1. 기업 삭제\n"
            "2. 물류센터 삭제\n"
            "3. 운전자 삭제\n"
            "4. 차량 삭제\n"
            "5. 차량 배정 삭제\n"
            "0. 돌아가기\n"
        )

        choice = input("메뉴 선택: ").strip()

        try:
            if choice == "1":
                remove_company()
            elif choice == "2":
                remove_center()
            elif choice == "3":
                remove_driver()
            elif choice == "4":
                remove_vehicle()
            elif choice == "5":
                remove_assignment()
            elif choice == "0":
                break
            else:
                print("0~5 사이의 번호를 입력해 주세요.")
        except Exception as exc:
            print(f"작업 중 오류가 발생했습니다: {exc}")


# =====================================================
# 메인 메뉴
# =====================================================
def main():
    initialize_database()

    while True:
        print(
            "\n"
            "====================================\n"
            " SafeLogi AI 고객 DB 관리 시스템\n"
            "====================================\n"
            "1. 기업 등록\n"
            "2. 물류센터 등록\n"
            "3. 운전자 등록\n"
            "4. 차량 등록\n"
            "5. 운전자-차량 배정\n"
            "6. 전체 정보 조회\n"
            "7. 데이터 삭제\n"
            "0. 종료\n"
        )

        choice = input("메뉴 선택: ").strip()

        try:
            if choice == "1":
                register_company()
            elif choice == "2":
                register_center()
            elif choice == "3":
                register_driver()
            elif choice == "4":
                register_vehicle()
            elif choice == "5":
                register_assignment()
            elif choice == "6":
                show_all_data()
            elif choice == "7":
                delete_menu()
            elif choice == "0":
                print("\n프로그램을 종료합니다.")
                break
            else:
                print("\n0~7 사이의 번호를 입력해 주세요.")
        except Exception as exc:
            print("\n작업 중 오류가 발생했습니다.")
            print(f"오류 내용: {exc}")


if __name__ == "__main__":
    main()
