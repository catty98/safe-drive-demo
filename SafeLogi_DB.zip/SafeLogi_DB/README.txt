SafeLogi AI 고객 DB 관리 시스템

실행 방법
1. Python 3가 설치되어 있어야 합니다.
2. 이 폴더에서 다음 명령을 실행합니다.

   python main.py

3. 별도 pip 설치는 필요하지 않습니다.
   sqlite3와 pathlib는 Python 기본 라이브러리입니다.

구성
- main.py: 사용자 메뉴 및 입력 처리
- database.py: SQLite 연결/등록/조회/삭제/검증
- schema.sql: DB 테이블 정의
- data/safelogi.db: 실행 시 자동 생성되는 SQLite DB

주요 보완 사항
- company_exists / driver_exists / vehicle_exists 포함
- 존재하지 않는 ID 입력 사전 차단
- FOREIGN KEY ON DELETE CASCADE 적용
- 데이터 삭제 기능 포함
- 테이블이 완전히 비면 AUTOINCREMENT 순서 초기화
- 서로 다른 회사의 운전자와 차량 배정 방지
