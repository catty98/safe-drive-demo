import sqlite3
from pathlib import Path


# =====================================================
# 경로 설정
# =====================================================
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "safelogi.db"
SCHEMA_PATH = BASE_DIR / "schema.sql"


# =====================================================
# DB 연결 / 초기화
# =====================================================
def get_connection():
    """SQLite DB에 연결하고 외래키 제약조건을 활성화합니다."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database():
    """schema.sql을 읽어 필요한 테이블을 생성합니다."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if not SCHEMA_PATH.exists():
        raise FileNotFoundError(
            f"schema.sql을 찾을 수 없습니다: {SCHEMA_PATH}"
        )

    schema = SCHEMA_PATH.read_text(encoding="utf-8")

    connection = get_connection()
    try:
        connection.executescript(schema)
        connection.commit()
    finally:
        connection.close()


# =====================================================
# 내부 보조 함수
# =====================================================
def _reset_sequence_if_empty(connection, table_name):
    """
    테이블이 완전히 비어 있을 때만 AUTOINCREMENT 기록을 초기화합니다.

    예:
    - 1번만 존재 -> 1번 삭제 -> 다음 등록은 다시 1번
    - 1, 2번 존재 -> 1번만 삭제 -> 다음 등록은 3번
    """
    allowed_tables = {
        "company",
        "logistics_center",
        "driver",
        "vehicle",
        "driver_vehicle_assignment",
    }

    if table_name not in allowed_tables:
        raise ValueError(f"허용되지 않은 테이블입니다: {table_name}")

    count = connection.execute(
        f"SELECT COUNT(*) FROM {table_name}"
    ).fetchone()[0]

    if count == 0:
        connection.execute(
            "DELETE FROM sqlite_sequence WHERE name = ?",
            (table_name,),
        )


def _reset_all_empty_sequences(connection):
    """CASCADE 삭제 후 비어진 테이블들의 ID 순서를 함께 초기화합니다."""
    for table_name in (
        "company",
        "logistics_center",
        "driver",
        "vehicle",
        "driver_vehicle_assignment",
    ):
        _reset_sequence_if_empty(connection, table_name)


# =====================================================
# ID 존재 여부 확인
# =====================================================
def company_exists(company_id):
    connection = get_connection()
    try:
        row = connection.execute(
            "SELECT 1 FROM company WHERE company_id = ?",
            (company_id,),
        ).fetchone()
        return row is not None
    finally:
        connection.close()


def driver_exists(driver_id):
    connection = get_connection()
    try:
        row = connection.execute(
            "SELECT 1 FROM driver WHERE driver_id = ?",
            (driver_id,),
        ).fetchone()
        return row is not None
    finally:
        connection.close()


def vehicle_exists(vehicle_id):
    connection = get_connection()
    try:
        row = connection.execute(
            "SELECT 1 FROM vehicle WHERE vehicle_id = ?",
            (vehicle_id,),
        ).fetchone()
        return row is not None
    finally:
        connection.close()


# =====================================================
# 등록 기능
# =====================================================
def add_company(company_name, business_type, main_cargo_type):
    connection = get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO company (
                company_name,
                business_type,
                main_cargo_type
            )
            VALUES (?, ?, ?)
            """,
            (company_name, business_type, main_cargo_type),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


def add_logistics_center(
    company_id,
    center_name,
    address,
    latitude,
    longitude,
    open_time,
    close_time,
):
    if not company_exists(company_id):
        raise ValueError("존재하지 않는 기업 ID입니다.")

    connection = get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO logistics_center (
                company_id,
                center_name,
                address,
                latitude,
                longitude,
                open_time,
                close_time
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                company_id,
                center_name,
                address,
                latitude,
                longitude,
                open_time,
                close_time,
            ),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


def add_driver(
    company_id,
    driver_name,
    age,
    driving_experience,
    license_type,
    accident_history_count,
):
    if not company_exists(company_id):
        raise ValueError("존재하지 않는 기업 ID입니다.")

    connection = get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO driver (
                company_id,
                driver_name,
                age,
                driving_experience,
                license_type,
                accident_history_count
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                company_id,
                driver_name,
                age,
                driving_experience,
                license_type,
                accident_history_count,
            ),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


def add_vehicle(
    company_id,
    vehicle_number,
    vehicle_type,
    vehicle_model,
    model_year,
    max_load_weight,
    default_cargo_type,
):
    if not company_exists(company_id):
        raise ValueError("존재하지 않는 기업 ID입니다.")

    connection = get_connection()
    try:
        cursor = connection.execute(
            """
            INSERT INTO vehicle (
                company_id,
                vehicle_number,
                vehicle_type,
                vehicle_model,
                model_year,
                max_load_weight,
                default_cargo_type
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                company_id,
                vehicle_number,
                vehicle_type,
                vehicle_model,
                model_year,
                max_load_weight,
                default_cargo_type,
            ),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


def assign_vehicle(driver_id, vehicle_id):
    if not driver_exists(driver_id):
        raise ValueError("존재하지 않는 운전자 ID입니다.")

    if not vehicle_exists(vehicle_id):
        raise ValueError("존재하지 않는 차량 ID입니다.")

    connection = get_connection()
    try:
        # 서로 다른 회사의 운전자와 차량이 배정되는 것을 방지합니다.
        row = connection.execute(
            """
            SELECT
                d.company_id AS driver_company_id,
                v.company_id AS vehicle_company_id
            FROM driver d
            CROSS JOIN vehicle v
            WHERE d.driver_id = ?
              AND v.vehicle_id = ?
            """,
            (driver_id, vehicle_id),
        ).fetchone()

        if row is None:
            raise ValueError("운전자 또는 차량 정보를 찾지 못했습니다.")

        if row["driver_company_id"] != row["vehicle_company_id"]:
            raise ValueError(
                "서로 다른 기업에 소속된 운전자와 차량은 배정할 수 없습니다."
            )

        cursor = connection.execute(
            """
            INSERT INTO driver_vehicle_assignment (
                driver_id,
                vehicle_id
            )
            VALUES (?, ?)
            """,
            (driver_id, vehicle_id),
        )
        connection.commit()
        return cursor.lastrowid
    finally:
        connection.close()


# =====================================================
# 조회 기능
# =====================================================
def get_companies():
    connection = get_connection()
    try:
        return connection.execute(
            """
            SELECT *
            FROM company
            ORDER BY company_id
            """
        ).fetchall()
    finally:
        connection.close()


def get_centers():
    connection = get_connection()
    try:
        return connection.execute(
            """
            SELECT
                lc.center_id,
                lc.company_id,
                c.company_name,
                lc.center_name,
                lc.address,
                lc.latitude,
                lc.longitude,
                lc.open_time,
                lc.close_time
            FROM logistics_center lc
            JOIN company c
                ON lc.company_id = c.company_id
            ORDER BY lc.center_id
            """
        ).fetchall()
    finally:
        connection.close()


def get_drivers():
    connection = get_connection()
    try:
        return connection.execute(
            """
            SELECT
                d.driver_id,
                d.company_id,
                c.company_name,
                d.driver_name,
                d.age,
                d.driving_experience,
                d.license_type,
                d.accident_history_count
            FROM driver d
            JOIN company c
                ON d.company_id = c.company_id
            ORDER BY d.driver_id
            """
        ).fetchall()
    finally:
        connection.close()


def get_vehicles():
    connection = get_connection()
    try:
        return connection.execute(
            """
            SELECT
                v.vehicle_id,
                v.company_id,
                c.company_name,
                v.vehicle_number,
                v.vehicle_type,
                v.vehicle_model,
                v.model_year,
                v.max_load_weight,
                v.default_cargo_type
            FROM vehicle v
            JOIN company c
                ON v.company_id = c.company_id
            ORDER BY v.vehicle_id
            """
        ).fetchall()
    finally:
        connection.close()


def get_assignments():
    connection = get_connection()
    try:
        return connection.execute(
            """
            SELECT
                a.assignment_id,
                d.company_id,
                c.company_name,
                a.driver_id,
                d.driver_name,
                a.vehicle_id,
                v.vehicle_number,
                v.vehicle_type,
                a.assigned_at,
                a.released_at,
                a.active
            FROM driver_vehicle_assignment a
            JOIN driver d
                ON a.driver_id = d.driver_id
            JOIN vehicle v
                ON a.vehicle_id = v.vehicle_id
            JOIN company c
                ON d.company_id = c.company_id
            ORDER BY a.assignment_id
            """
        ).fetchall()
    finally:
        connection.close()


# =====================================================
# 삭제 기능
# =====================================================
def delete_company(company_id):
    connection = get_connection()
    try:
        cursor = connection.execute(
            "DELETE FROM company WHERE company_id = ?",
            (company_id,),
        )
        deleted = cursor.rowcount > 0

        if deleted:
            # ON DELETE CASCADE로 관련 테이블도 비었을 수 있으므로 모두 확인합니다.
            _reset_all_empty_sequences(connection)

        connection.commit()
        return deleted
    finally:
        connection.close()


def delete_center(center_id):
    connection = get_connection()
    try:
        cursor = connection.execute(
            "DELETE FROM logistics_center WHERE center_id = ?",
            (center_id,),
        )
        deleted = cursor.rowcount > 0

        if deleted:
            _reset_sequence_if_empty(connection, "logistics_center")

        connection.commit()
        return deleted
    finally:
        connection.close()


def delete_driver(driver_id):
    connection = get_connection()
    try:
        cursor = connection.execute(
            "DELETE FROM driver WHERE driver_id = ?",
            (driver_id,),
        )
        deleted = cursor.rowcount > 0

        if deleted:
            _reset_sequence_if_empty(connection, "driver")
            _reset_sequence_if_empty(
                connection,
                "driver_vehicle_assignment",
            )

        connection.commit()
        return deleted
    finally:
        connection.close()


def delete_vehicle(vehicle_id):
    connection = get_connection()
    try:
        cursor = connection.execute(
            "DELETE FROM vehicle WHERE vehicle_id = ?",
            (vehicle_id,),
        )
        deleted = cursor.rowcount > 0

        if deleted:
            _reset_sequence_if_empty(connection, "vehicle")
            _reset_sequence_if_empty(
                connection,
                "driver_vehicle_assignment",
            )

        connection.commit()
        return deleted
    finally:
        connection.close()


def delete_assignment(assignment_id):
    connection = get_connection()
    try:
        cursor = connection.execute(
            """
            DELETE FROM driver_vehicle_assignment
            WHERE assignment_id = ?
            """,
            (assignment_id,),
        )
        deleted = cursor.rowcount > 0

        if deleted:
            _reset_sequence_if_empty(
                connection,
                "driver_vehicle_assignment",
            )

        connection.commit()
        return deleted
    finally:
        connection.close()
